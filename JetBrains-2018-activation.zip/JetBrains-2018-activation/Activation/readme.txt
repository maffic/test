Usage:
1. Click "Configure" -> "Edit Custom VM Options ..."
2. Append "-javaagent:{JetbrainsCrackPath}" to end line.
     ag: -javaagent:/Users/rover12421/JetbrainsCrack.jar
3. Restart IDE
4. Entry any character.
5. If you need modify "licenseeName", please modify and using key:
{"licenseId":"ThisCrackLicenseId",
"licenseeName":"Rover12421",
"assigneeName":"Rover12421",
"assigneeEmail":"rover12421@163.com",
"licenseRestriction":"By Rover12421 Crack, Only Test! Please support genuine!!!",
"checkConcurrentUse":false,
"products":[
{"code":"II","paidUpTo":"2099-12-31"},
{"code":"DM","paidUpTo":"2099-12-31"},
{"code":"AC","paidUpTo":"2099-12-31"},
{"code":"RS0","paidUpTo":"2099-12-31"},
{"code":"WS","paidUpTo":"2099-12-31"},
{"code":"DPN","paidUpTo":"2099-12-31"},
{"code":"RC","paidUpTo":"2099-12-31"},
{"code":"PS","paidUpTo":"2099-12-31"},
{"code":"DC","paidUpTo":"2099-12-31"},
{"code":"RM","paidUpTo":"2099-12-31"},
{"code":"CL","paidUpTo":"2099-12-31"},
{"code":"PC","paidUpTo":"2099-12-31"},
{"code":"DB","paidUpTo":"2099-12-31"},
{"code":"GO","paidUpTo":"2099-12-31"},
{"code":"RD","paidUpTo":"2099-12-31"}
],
"hash":"2911276/0",
"gracePeriodDays":7,
"autoProlongated":false}
6. If show error msg : "Error opening zip file or JAR manifest missing : JetbrainsCrack.jar"
    Please modify the jar file path to absolute path. 